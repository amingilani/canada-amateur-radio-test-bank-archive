Each record has the following data, separated by ";"

Question ID
English Question
Correct English Answer
Incorrect English Answer 1
Incorrect English Answer 2
Incorrect English Answer 3
French Question
Correct French Answer
Incorrect French Answer 1
Incorrect French Answer 2
Incorrect French Answer 3

